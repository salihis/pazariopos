// server/prisma/seed.ts
// ─────────────────────────────────────────────────────────────
// Seeds the minimal data the hello-world PosScreen demo needs:
//   • `demo-customer-1` — the account the "Check Account Balance"
//     button in packages/ui/src/PosScreen.tsx queries.
//
// Run with: pnpm --filter @pos-erp/server exec prisma db seed
// (also runs automatically after `prisma migrate dev`)
// ─────────────────────────────────────────────────────────────

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  const demoAccount = await prisma.account.upsert({
    where: { id: 'demo-customer-1' },
    update: {},
    create: {
      id: 'demo-customer-1',
      name: 'Demo Customer',
      balance: 15000,   // 150.00 in minor units — matches money() formatting in PosScreen
    },
  })

  console.log('Seeded account:', demoAccount)
}

main()
  .catch(err => {
    console.error('Seed failed:', err)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
