// packages/core/src/types/domain.ts
// ─────────────────────────────────────────────────────────────
// Shared domain types — consumed by all packages in the monorepo
// ─────────────────────────────────────────────────────────────

// ── Product & Cart ────────────────────────────────────────────

export interface Product {
  id: string
  sku: string
  name: string
  barcode: string[]
  price: number        // stored in smallest currency unit (kuruş / cent)
  taxRate: number      // e.g. 0.18 for 18% VAT
  stock: number
  unit: 'piece' | 'box' | 'kg' | 'lt'
  categoryId: string
  warehouseId: string
}

export interface CartLine {
  product: Product
  quantity: number
  unitPrice: number    // price at time of sale (price may change later)
  discountAmount: number
  taxAmount: number
  total: number        // (unitPrice - discountAmount + taxAmount) * quantity
}

// ── Sale ─────────────────────────────────────────────────────

export type PaymentMethod = 'cash' | 'card' | 'transfer' | 'cheque' | 'account'

export interface PaymentLine {
  method: PaymentMethod
  amount: number
  reference?: string   // card auth code, cheque no, etc.
}

export type SaleStatus = 'completed' | 'returned' | 'partial_return' | 'voided'
export type SyncStatus  = 'synced' | 'pending' | 'conflict' | 'error'

export interface Sale {
  id: string
  localId: string      // UUID generated on the device before server assigns an id
  branchId: string
  registerId: string
  cashierId: string
  customerId?: string

  lines: CartLine[]
  payments: PaymentLine[]

  subtotal: number
  discountTotal: number
  taxTotal: number
  grandTotal: number
  changeGiven: number

  status: SaleStatus

  // Audit
  createdAt: string    // ISO-8601
  updatedAt: string

  // Sync (desktop only — ignored on server)
  deviceId?: string
  syncStatus?: SyncStatus
  syncedAt?: string | null
}

// ── Report ───────────────────────────────────────────────────

export interface ReportData {
  title: string
  generatedAt: string
  period: { from: string; to: string }
  rows: Record<string, unknown>[]
  summary?: Record<string, number>
}

// ── Sync Queue ───────────────────────────────────────────────

export type SyncOperation = 'INSERT' | 'UPDATE' | 'DELETE'

export interface SyncQueueItem {
  id: string
  tableName: string
  operation: SyncOperation
  recordId: string
  payload: string      // JSON.stringify(record)
  createdAt: string
  retryCount: number
  lastError?: string
}

// ── Network ──────────────────────────────────────────────────

export type NetworkStatus = 'online' | 'offline' | 'degraded'
