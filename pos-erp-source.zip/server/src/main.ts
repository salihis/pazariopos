// server/src/main.ts
// ─────────────────────────────────────────────────────────────
// Fastify v5 API entry point.
// Serves the endpoints consumed by packages/core/src/api/salesApi.ts:
//   GET  /api/health              — used by NetworkMonitor's ping
//   POST /api/sales               — online sale submission
//   POST /api/sales/sync          — sync engine pushes queued sales
//   GET  /api/accounts/:id/balance — MUST be reachable only when online
// ─────────────────────────────────────────────────────────────

import Fastify from 'fastify'
import cors from '@fastify/cors'

import { healthRoutes }   from './routes/health'
import { salesRoutes }    from './routes/sales'
import { accountsRoutes } from './routes/accounts'

const PORT = Number(process.env.PORT ?? 3000)
const HOST = process.env.HOST ?? '0.0.0.0'

async function buildServer() {
  const app = Fastify({
    logger: {
      level: process.env.LOG_LEVEL ?? 'info',
      transport: process.env.NODE_ENV !== 'production'
        ? { target: 'pino-pretty', options: { colorize: true } }
        : undefined,
    },
  })

  await app.register(cors, {
    origin: process.env.CORS_ORIGIN?.split(',') ?? ['http://localhost:5173', 'http://localhost:1420'],
  })

  await app.register(healthRoutes,   { prefix: '/api/health' })
  await app.register(salesRoutes,    { prefix: '/api/sales' })
  await app.register(accountsRoutes, { prefix: '/api/accounts' })

  return app
}

buildServer()
  .then(app => app.listen({ port: PORT, host: HOST }))
  .then(() => {
    console.log(`[server] listening on http://localhost:${PORT}`)
  })
  .catch(err => {
    console.error('[server] failed to start:', err)
    process.exit(1)
  })
