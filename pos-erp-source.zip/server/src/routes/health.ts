// server/src/routes/health.ts
// ─────────────────────────────────────────────────────────────
// NetworkMonitor (packages/core) pings this with a HEAD request
// every `pingIntervalMs`. Keep this handler trivially cheap —
// no DB calls — so it never becomes the bottleneck it's supposed
// to be checking for.
// ─────────────────────────────────────────────────────────────

import type { FastifyPluginAsync } from 'fastify'

export const healthRoutes: FastifyPluginAsync = async (app) => {
  app.get('/', async () => ({ status: 'ok', timestamp: new Date().toISOString() }))

  // Fastify auto-handles HEAD for GET routes with the same handler,
  // but we register it explicitly for clarity since NetworkMonitor
  // specifically issues `method: 'HEAD'`.
  app.head('/', async (_req, reply) => {
    reply.code(204).send()
  })
}
