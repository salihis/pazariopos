// server/src/routes/accounts.ts
// ─────────────────────────────────────────────────────────────
// Implements GET /api/accounts/:id/balance, called by
// packages/core/src/services/AccountBalanceService.ts.
//
// Architecture rule: §7 OFFLINE MODE — this endpoint is ONLY ever
// reachable when the client is online (AccountBalanceService throws
// OfflineBalanceError before it even attempts the request). There is
// no offline fallback here by design: a stale balance could let a
// cashier authorize a sale beyond the real credit limit.
// ─────────────────────────────────────────────────────────────

import type { FastifyPluginAsync } from 'fastify'
import { z } from 'zod'

import { prisma } from '../db/prisma'

const paramsSchema = z.object({
  id: z.string().min(1),
})

export const accountsRoutes: FastifyPluginAsync = async (app) => {
  app.get('/:id/balance', async (req, reply) => {
    const parseResult = paramsSchema.safeParse(req.params)
    if (!parseResult.success) {
      return reply.code(400).send({ error: 'ValidationError', issues: parseResult.error.issues })
    }

    const { id } = parseResult.data

    const account = await prisma.account.findUnique({ where: { id } })

    if (!account) {
      return reply.code(404).send({
        error: 'NotFound',
        message: `Account "${id}" does not exist.`,
      })
    }

    return reply.send({
      accountId: account.id,
      balance: account.balance,
      asOf: new Date().toISOString(),
    })
  })
}
