// packages/core/src/api/salesApi.ts
// ─────────────────────────────────────────────────────────────
// Thin fetch wrapper around the Fastify REST endpoints.
// Kept dependency-free (no axios) to minimize bundle size on the
// web target; swap for axios here if interceptors are needed later.
// ─────────────────────────────────────────────────────────────

import type { Sale } from '../types/domain'

// packages/core must stay platform-agnostic (see CODING_GUIDELINES.md §2) —
// it cannot assume a Vite bundler is present (the desktop Rust side has no
// bundler at all). App entry points (apps/web/src/main.tsx,
// apps/desktop/src/main.tsx) call `setApiBaseUrl()` during startup using
// their own `import.meta.env.VITE_API_BASE_URL`, where Vite's types are
// already configured. This module only owns a sane default + the setter.
let apiBase = 'http://localhost:3000'

/** Called once at app startup by apps/web or apps/desktop. */
export function setApiBaseUrl(url: string): void {
  apiBase = url
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message)
    this.name = 'ApiError'
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${apiBase}${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...init?.headers,
    },
  })

  if (!res.ok) {
    const body = await res.text().catch(() => '')
    throw new ApiError(res.status, body || res.statusText)
  }

  // 204 No Content etc.
  if (res.status === 204) return undefined as T

  return (await res.json()) as T
}

export const salesApi = {
  /** Persists a completed sale on the server. Used in the ONLINE branch of useSaleStore. */
  createSale(sale: Sale): Promise<Sale> {
    return request<Sale>('/api/sales', {
      method: 'POST',
      body: JSON.stringify(sale),
    })
  },

  /** Used by the sync engine to push a queued offline sale once connectivity returns. */
  syncSale(sale: Sale): Promise<Sale> {
    return request<Sale>('/api/sales/sync', {
      method: 'POST',
      body: JSON.stringify(sale),
    })
  },
}

export const accountsApi = {
  /**
   * Fetches the live balance for a customer/supplier account.
   * Per architecture rule: account balances are NEVER served from a
   * local cache — a stale balance could authorize a sale beyond the
   * real credit limit. Callers must catch the offline rejection.
   */
  getBalance(accountId: string): Promise<{ accountId: string; balance: number; asOf: string }> {
    return request(`/api/accounts/${accountId}/balance`)
  },
}
