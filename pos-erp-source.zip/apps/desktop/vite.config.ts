// apps/desktop/vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Fixed port required: tauri.conf.json's `build.devUrl` points at
// http://localhost:1420 and must match exactly.
export default defineConfig({
  plugins: [react()],
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    watch: {
      // Don't trigger a Vite reload when Rust recompiles.
      ignored: ['**/src-tauri/**'],
    },
  },
  build: {
    outDir: 'dist',
    // Tauri uses Chromium on Windows/Linux and WebKit on macOS —
    // target a reasonably modern baseline for both.
    target: process.env.TAURI_ENV_PLATFORM === 'windows' ? 'chrome105' : 'safari13',
    sourcemap: !!process.env.TAURI_ENV_DEBUG,
  },
})
