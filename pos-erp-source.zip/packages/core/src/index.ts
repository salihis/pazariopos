// packages/core/src/index.ts
// ─────────────────────────────────────────────────────────────
// Public API of @pos-erp/core. UI apps (web + desktop) should only
// import from this barrel — never reach into services/web/* or
// services/desktop/* directly. This keeps the platform switch
// (factory pattern) as the single source of truth.
// ─────────────────────────────────────────────────────────────

// Types
export * from './types/domain'

// Platform detection
export { platform } from './platform/PlatformDetectionService'
export type { PlatformType } from './platform/PlatformDetectionService'

// Interfaces (for typing custom mocks in tests)
export type { IPrinterService, PrinterConfig, PrintResult, PaperWidth } from './services/interfaces/IPrinterService'
export { DEFAULT_PRINTER_CONFIG } from './services/interfaces/IPrinterService'
export type { IBarcodeService, BarcodeEvent, BarcodeHandler, BarcodeFormat } from './services/interfaces/IBarcodeService'
export type { INetworkMonitor, NetworkStatusHandler } from './services/interfaces/INetworkMonitor'
export type { ILocalSaleQueue } from './services/interfaces/ILocalSaleQueue'

// Factories — the only way UI code should obtain a service instance
export { getPrinterService } from './services/printerServiceFactory'
export { getBarcodeService } from './services/barcodeServiceFactory'
export { getNetworkMonitor } from './services/NetworkMonitor'
export { getLocalSaleQueue } from './services/localSaleQueueFactory'

// Account balance (offline-forbidden by design)
export { accountBalanceService, OfflineBalanceError } from './services/AccountBalanceService'
export type { AccountBalance } from './services/AccountBalanceService'

// API client (used directly by the store; exposed for advanced use / testing)
export { salesApi, accountsApi, ApiError, setApiBaseUrl } from './api/salesApi'

// Store
export { useSaleStore } from './store/useSaleStore'
export type { SaleStoreState, SaleSubmitOutcome } from './store/useSaleStore'
