// server/src/routes/sales.ts
// ─────────────────────────────────────────────────────────────
// Implements the two endpoints packages/core/src/api/salesApi.ts
// calls:
//   POST /api/sales       — online branch of useSaleStore.submitSale()
//   POST /api/sales/sync  — sync engine pushing a queued offline sale
//
// Both endpoints are intentionally idempotent on `localId`: the
// device generates that UUID once, before it knows whether it will
// go straight to the API or sit in the offline queue for a while.
// If the same localId arrives twice (e.g. a retried sync after a
// dropped response), we return the existing row instead of erroring
// or double-inserting. See ARCHITECTURE.md §4a Sync Architecture.
// ─────────────────────────────────────────────────────────────

import type { FastifyPluginAsync } from 'fastify'
import { Prisma } from '@prisma/client'

import { prisma } from '../db/prisma'
import { saleSchema } from '../schemas/sale'
import { toDomainSale } from '../mappers/saleMapper'

const saleInclude = { lines: true, payments: true } satisfies Prisma.SaleInclude

async function upsertSaleByLocalId(input: ReturnType<typeof saleSchema.parse>) {
  const existing = await prisma.sale.findUnique({
    where: { localId: input.localId },
    include: saleInclude,
  })

  if (existing) {
    // Idempotent replay — the device already got this persisted once.
    return existing
  }

  return prisma.sale.create({
    data: {
      localId: input.localId,
      branchId: input.branchId,
      registerId: input.registerId,
      cashierId: input.cashierId,
      customerId: input.customerId,

      subtotal: input.subtotal,
      discountTotal: input.discountTotal,
      taxTotal: input.taxTotal,
      grandTotal: input.grandTotal,
      changeGiven: input.changeGiven,

      status: input.status,
      deviceId: input.deviceId,
      syncStatus: 'synced',   // once it lands here, it IS synced
      syncedAt: new Date(),

      lines: {
        create: input.lines.map(line => ({
          productId: line.product.id,
          productName: line.product.name,
          quantity: line.quantity,
          unitPrice: line.unitPrice,
          discountAmount: line.discountAmount,
          taxAmount: line.taxAmount,
          total: line.total,
        })),
      },
      payments: {
        create: input.payments.map(payment => ({
          method: payment.method,
          amount: payment.amount,
          reference: payment.reference,
        })),
      },
    },
    include: saleInclude,
  })
}

export const salesRoutes: FastifyPluginAsync = async (app) => {
  // ── POST /api/sales — direct online submission ──
  app.post('/', async (req, reply) => {
    const parseResult = saleSchema.safeParse(req.body)
    if (!parseResult.success) {
      return reply.code(400).send({
        error: 'ValidationError',
        issues: parseResult.error.issues,
      })
    }

    try {
      const row = await upsertSaleByLocalId(parseResult.data)
      return reply.code(201).send(toDomainSale(row))
    } catch (err) {
      app.log.error(err, 'Failed to persist sale')
      return reply.code(500).send({ error: 'InternalError', message: 'Could not save sale.' })
    }
  })

  // ── POST /api/sales/sync — pushed from the desktop offline queue ──
  app.post('/sync', async (req, reply) => {
    const parseResult = saleSchema.safeParse(req.body)
    if (!parseResult.success) {
      return reply.code(400).send({
        error: 'ValidationError',
        issues: parseResult.error.issues,
      })
    }

    try {
      const row = await upsertSaleByLocalId(parseResult.data)
      return reply.code(200).send(toDomainSale(row))
    } catch (err) {
      app.log.error(err, 'Failed to sync sale')
      return reply.code(500).send({ error: 'InternalError', message: 'Could not sync sale.' })
    }
  })
}
