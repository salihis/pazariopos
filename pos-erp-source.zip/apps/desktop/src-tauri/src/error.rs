// apps/desktop/src-tauri/src/error.rs
// ─────────────────────────────────────────────────────────────
// Central error type. Tauri commands must return `Result<T, E>`
// where E: Serialize, so every error path funnels through here
// and is serialized as a plain string message to the frontend.
// ─────────────────────────────────────────────────────────────

use serde::Serialize;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum AppError {
    #[error("printer error: {0}")]
    Printer(String),

    #[error("serial port error: {0}")]
    SerialPort(String),

    #[error("database error: {0}")]
    Database(#[from] sqlx::Error),

    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    #[error("sync error: {0}")]
    Sync(String),

    #[error("not found: {0}")]
    NotFound(String),
}

// Tauri requires command errors to implement Serialize so they can
// cross the IPC boundary as JSON and be caught in the TS `invoke()` call.
impl Serialize for AppError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(&self.to_string())
    }
}

pub type AppResult<T> = Result<T, AppError>;
